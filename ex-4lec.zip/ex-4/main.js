/* NO.1 */
const arr = [3, 1, 7, 2];

function findMin(arr) {
  let min = arr[0];
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] < min) {
      min = arr[i];
    }
  }
  console.log(min);
}

findMin(arr);

/* NO.2 */
let balance = 200;
function buy(price, tex_rate, balance) {
  if (price == 30 && tex_rate == 10) {
    console.log("YES");
  } else {
    console.log("NO");
  }
}

buy(30, 10, balance);
