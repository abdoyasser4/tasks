document.write("open console")
/////////////////////////ex 1/////////////////////////////
let fruits="Banana";
//let fruits="Apple";
switch(fruits){
case "Banana":
    alert("hello");
    break;
case "Apple":
    alert("welcome");
    break;
default:
     alert("not a fruits");
}
////////////////////////////////
let x=3;
let y=2;
//let x=2;
//let y=2;
if(x>y){
    alert("hello world")
}else{
    alert("goodbye")
}
/////////////////////////ex 2/////////////////////////////
const fruts =["Banana","Orange","Apple","Kiwi"]

for(i=0;i<fruts.length;i++){
    console.log(fruts[i]);
}
////////////////////////////////
for(i=0;i<10;i++){
    console.log(i);
}
////////////////////////////////
for(i=0;i<10;i+=2){
    console.log(i);
}
/////////////////////////ex 3/////////////////////////////
const frut =["Banana","Orange","Apple","Kiwi"]
frut.pop();
console.log(frut);
frut.push("Kiwi");
console.log(frut);
console.log(frut.sort());